alert("Welcome To Facebook's Login Page.");
alert("Before Uploading Content Log In And accept Our Terms Of Services (TOS) ");