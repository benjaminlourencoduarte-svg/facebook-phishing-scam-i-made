import http.server
import socketserver
import os

# Folder containing your HTML files
folder = r"C:\Users\benja\OneDrive\Área de Trabalho\other files\tttt\ms"

# Change working directory to that folder
os.chdir(folder)

PORT = 8000

class Handler(http.server.SimpleHTTPRequestHandler):
    pass

with socketserver.TCPServer(("", PORT), Handler) as httpd:
    print(f"Serving folder:\n  {folder}")
    print(f"Open your main file at:\n  http://localhost:{PORT}/fbook.html")
    print(f"Or browse all files at:\n  http://localhost:{PORT}/")
    httpd.serve_forever()
