/*  
   Index-Apache4.js  
   Anti‑Lag Engine (SAFE VERSION)
   Only touches visual elements. Never modifies <head>, <meta>, <script>, etc.
*/

(function () {

    const FPS_CRITICAL = 25;
    const MAX_DELAY = 120;

    let lastFrame = performance.now();
    let fps = 60;
    let delay = 0;

    // Tags that are SAFE to modify
    const VISUAL_TAGS = [
        "div","span","p","img","button","a","section","article",
        "header","footer","nav","main","ul","ol","li","input",
        "textarea","label","form","canvas"
    ];

    // === FPS MONITOR ===
    function trackFPS() {
        const now = performance.now();
        fps = 1000 / (now - lastFrame);
        lastFrame = now;
        requestAnimationFrame(trackFPS);
    }
    requestAnimationFrame(trackFPS);

    // === EVENT LOOP LAG DETECTOR ===
    function monitorDelay() {
        const start = performance.now();
        setTimeout(() => {
            delay = performance.now() - start;
        }, 0);
    }
    setInterval(monitorDelay, 100);

    // === AUTO‑STABILIZER (SAFE) ===
    function stabilizer() {
        if (fps < FPS_CRITICAL || delay > MAX_DELAY) {

            // Only modify visual elements
            VISUAL_TAGS.forEach(tag => {
                document.querySelectorAll(tag).forEach(el => {
                    if (!el.dataset.origAnim) {
                        el.dataset.origAnim = getComputedStyle(el).animationDuration;
                        el.dataset.origTrans = getComputedStyle(el).transitionDuration;
                    }

                    el.style.animationDuration = "calc(" + el.dataset.origAnim + " * 1.5)";
                    el.style.transitionDuration = "calc(" + el.dataset.origTrans + " * 1.5)";
                });
            });

            requestIdleCallback(() => {});
        }
    }
    setInterval(stabilizer, 200);

})();
